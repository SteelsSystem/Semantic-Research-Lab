#!/usr/bin/env bash
set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

echo ">>> Launching VaporSphere Dialectical Lab (macOS Portable)..."

if command -v node &>/dev/null; then
    (sleep 1.2 && open "http://localhost:3000") &
    npx tsx server.ts
else
    open "$DIR/dist/index.html"
fi
