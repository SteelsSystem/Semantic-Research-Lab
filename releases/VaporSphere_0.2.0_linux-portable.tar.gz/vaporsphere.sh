#!/usr/bin/env bash
set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

echo ">>> Launching VaporSphere Dialectical Lab (Portable)..."

if command -v node &>/dev/null; then
    echo "[*] Launching native dialectical backend on port 3000..."
    if command -v xdg-open &>/dev/null; then
        (sleep 1.2 && xdg-open "http://localhost:3000") &
    fi
    npx tsx server.ts
else
    echo "[*] Opening client bundle in default browser..."
    if command -v xdg-open &>/dev/null; then
        xdg-open "$DIR/dist/index.html"
    elif command -v sensible-browser &>/dev/null; then
        sensible-browser "$DIR/dist/index.html"
    fi
fi
